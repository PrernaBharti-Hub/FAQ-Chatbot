// Analytics module for chat data analysis
class Analytics {
    constructor() {
        this.chatHistory = [];
    }

    // Load chat history
    loadData() {
        this.chatHistory = storage.getHistory();
        return this.chatHistory;
    }

    // Get total number of chats
    getTotalChats() {
        return this.chatHistory.length;
    }

    // Get common issues grouped by category
    getCommonIssues() {
        const categoryCount = {};

        this.chatHistory.forEach(chat => {
            const category = chat.issueCategory;
            categoryCount[category] = (categoryCount[category] || 0) + 1;
        });

        // Sort by count
        const sorted = Object.entries(categoryCount)
            .sort((a, b) => b[1] - a[1])
            .map(([category, count]) => ({ category, count }));

        return sorted;
    }

    // Get top issue category
    getTopIssue() {
        const issues = this.getCommonIssues();
        return issues.length > 0 ? issues[0] : null;
    }

    // Get keyword frequency
    getKeywordFrequency(topN = 10) {
        const keywords = {};
        const stopWords = new Set(['the', 'is', 'at', 'which', 'on', 'a', 'an', 'and', 'or', 'but', 'in', 'with', 'to', 'for', 'of', 'as', 'i', 'my', 'me', 'you', 'your', 'it', 'this', 'that', 'how', 'do', 'does', 'can', 'could', 'would', 'what', 'when', 'where', 'why']);

        this.chatHistory.forEach(chat => {
            const words = chat.userMessage.toLowerCase()
                .replace(/[^\w\s]/g, '')
                .split(/\s+/);

            words.forEach(word => {
                if (word.length > 2 && !stopWords.has(word)) {
                    keywords[word] = (keywords[word] || 0) + 1;
                }
            });
        });

        // Sort and get top N
        const sorted = Object.entries(keywords)
            .sort((a, b) => b[1] - a[1])
            .slice(0, topN)
            .map(([word, count]) => ({ word, count }));

        return sorted;
    }

    // Get time-based patterns
    getTimePatterns() {
        const hourCount = new Array(24).fill(0);
        const dayCount = new Array(7).fill(0);

        this.chatHistory.forEach(chat => {
            const date = new Date(chat.timestamp);
            hourCount[date.getHours()]++;
            dayCount[date.getDay()]++;
        });

        return { hourCount, dayCount };
    }

    // Get last activity timestamp
    getLastActivity() {
        if (this.chatHistory.length === 0) return null;
        const lastChat = this.chatHistory[this.chatHistory.length - 1];
        return new Date(lastChat.timestamp);
    }

    // Get category distribution for charts
    getCategoryDistribution() {
        const issues = this.getCommonIssues();
        return {
            labels: issues.map(i => this.formatCategoryName(i.category)),
            data: issues.map(i => i.count),
            categories: issues
        };
    }

    // Format category name for display
    formatCategoryName(category) {
        const names = {
            'login': 'Login Issues',
            'password': 'Password Reset',
            'account': 'Account Management',
            'crash': 'App Crashes',
            'payment': 'Payment Issues',
            'profile': 'Profile Updates',
            'notification': 'Notifications',
            'sync': 'Data Sync',
            'feature': 'Feature Requests',
            'support': 'General Support',
            'general': 'General Queries'
        };
        return names[category] || category.charAt(0).toUpperCase() + category.slice(1);
    }

    // Get comprehensive analytics summary
    getSummary() {
        const totalChats = this.getTotalChats();
        const topIssue = this.getTopIssue();
        const lastActivity = this.getLastActivity();
        const issues = this.getCommonIssues();
        const keywords = this.getKeywordFrequency(10);

        return {
            totalChats,
            topIssue: topIssue ? this.formatCategoryName(topIssue.category) : 'N/A',
            topIssueCount: topIssue ? topIssue.count : 0,
            categoriesCount: issues.length,
            lastActivity: lastActivity ? this.formatTime(lastActivity) : 'Never',
            issues,
            keywords
        };
    }

    // Format time for display
    formatTime(date) {
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;

        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours}h ago`;

        const diffDays = Math.floor(diffHours / 24);
        if (diffDays < 7) return `${diffDays}d ago`;

        return date.toLocaleDateString();
    }

    // Get recent chats for table display
    getRecentChats(limit = 20) {
        return this.chatHistory
            .slice(-limit)
            .reverse()
            .map(chat => ({
                ...chat,
                formattedTime: new Date(chat.timestamp).toLocaleString(),
                categoryName: this.formatCategoryName(chat.issueCategory)
            }));
    }
}

// Export analytics instance
const analytics = new Analytics();
