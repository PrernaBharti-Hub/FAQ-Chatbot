// Dashboard module for visualization using Chart.js
class Dashboard {
    constructor() {
        this.charts = {};
        this.chartColors = {
            primary: 'rgba(99, 102, 241, 0.8)',
            secondary: 'rgba(236, 72, 153, 0.8)',
            accent: 'rgba(139, 92, 246, 0.8)',
            success: 'rgba(16, 185, 129, 0.8)',
            warning: 'rgba(245, 158, 11, 0.8)',
            danger: 'rgba(239, 68, 68, 0.8)',
            info: 'rgba(59, 130, 246, 0.8)',
        };
        this.colorPalette = [
            'rgba(99, 102, 241, 0.8)',
            'rgba(236, 72, 153, 0.8)',
            'rgba(139, 92, 246, 0.8)',
            'rgba(16, 185, 129, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(239, 68, 68, 0.8)',
            'rgba(59, 130, 246, 0.8)',
            'rgba(20, 184, 166, 0.8)',
            'rgba(251, 146, 60, 0.8)',
            'rgba(168, 85, 247, 0.8)',
        ];
    }

    // Initialize dashboard
    init() {
        this.loadData();
        this.updateStats();
        this.createCategoryChart();
        this.createKeywordChart();
        this.updateTable();
    }

    // Load data from analytics
    loadData() {
        analytics.loadData();
    }

    // Update statistics cards
    updateStats() {
        const summary = analytics.getSummary();

        document.getElementById('totalChats').textContent = summary.totalChats;
        document.getElementById('topIssue').textContent = summary.topIssue;
        document.getElementById('categoriesCount').textContent = summary.categoriesCount;
        document.getElementById('lastUpdate').textContent = summary.lastActivity;
    }

    // Create category distribution chart
    createCategoryChart() {
        const ctx = document.getElementById('categoryChart');
        if (!ctx) return;

        const distribution = analytics.getCategoryDistribution();

        // Destroy existing chart if any
        if (this.charts.category) {
            this.charts.category.destroy();
        }

        this.charts.category = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: distribution.labels,
                datasets: [{
                    label: 'Number of Issues',
                    data: distribution.data,
                    backgroundColor: this.colorPalette,
                    borderColor: this.colorPalette.map(c => c.replace('0.8', '1')),
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(15, 15, 35, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: 'rgba(99, 102, 241, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function (context) {
                                return `Issues: ${context.parsed.y}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#a0a0c0',
                            stepSize: 1
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)',
                            drawBorder: false
                        }
                    },
                    x: {
                        ticks: {
                            color: '#a0a0c0',
                            maxRotation: 45,
                            minRotation: 45
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    // Create keyword frequency chart
    createKeywordChart() {
        const ctx = document.getElementById('keywordChart');
        if (!ctx) return;

        const keywords = analytics.getKeywordFrequency(10);

        // Destroy existing chart if any
        if (this.charts.keyword) {
            this.charts.keyword.destroy();
        }

        this.charts.keyword = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: keywords.map(k => k.word.charAt(0).toUpperCase() + k.word.slice(1)),
                datasets: [{
                    label: 'Frequency',
                    data: keywords.map(k => k.count),
                    backgroundColor: this.colorPalette,
                    borderColor: '#1a1a2e',
                    borderWidth: 3,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: '#a0a0c0',
                            padding: 15,
                            font: {
                                size: 12
                            },
                            generateLabels: function (chart) {
                                const data = chart.data;
                                return data.labels.map((label, i) => ({
                                    text: `${label} (${data.datasets[0].data[i]})`,
                                    fillStyle: data.datasets[0].backgroundColor[i],
                                    hidden: false,
                                    index: i
                                }));
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(15, 15, 35, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: 'rgba(99, 102, 241, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function (context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    // Update data table
    updateTable() {
        const tableBody = document.getElementById('tableBody');
        if (!tableBody) return;

        const recentChats = analytics.getRecentChats(20);

        if (recentChats.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="no-data">No data available. Start chatting to see analytics!</td></tr>';
            return;
        }

        tableBody.innerHTML = recentChats.map(chat => `
            <tr>
                <td>${chat.formattedTime}</td>
                <td>${this.truncate(chat.userMessage, 50)}</td>
                <td>${this.truncate(chat.botReply, 60)}</td>
                <td><span class="category-badge category-${chat.issueCategory}">${chat.categoryName}</span></td>
            </tr>
        `).join('');
    }

    // Helper: truncate text
    truncate(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    // Refresh dashboard
    refresh() {
        this.loadData();
        this.updateStats();
        this.createCategoryChart();
        this.createKeywordChart();
        this.updateTable();
    }

    // Destroy all charts
    destroy() {
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.destroy();
        });
        this.charts = {};
    }
}

// Export dashboard instance
const dashboard = new Dashboard();
