// Storage module for chat history
class ChatStorage {
    constructor() {
        this.storageKey = 'faq_chat_history';
        this.loadFromLocalStorage();
    }

    // Save chat message to localStorage
    saveMessage(chatData) {
        let history = this.getHistory();
        history.push(chatData);

        try {
            localStorage.setItem(this.storageKey, JSON.stringify(history));
            return true;
        } catch (error) {
            console.error('Error saving to localStorage:', error);
            return false;
        }
    }

    // Get all chat history
    getHistory() {
        try {
            const data = localStorage.getItem(this.storageKey);
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('Error reading from localStorage:', error);
            return [];
        }
    }

    // Load from localStorage on initialization
    loadFromLocalStorage() {
        const history = this.getHistory();
        console.log(`Loaded ${history.length} messages from localStorage`);
        return history;
    }

    // Export chat history as JSON file
    exportToJSON() {
        const history = this.getHistory();

        if (history.length === 0) {
            alert('No chat history to export. Start a conversation first!');
            return;
        }

        const dataStr = JSON.stringify(history, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `chat_history_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        console.log('Chat history exported successfully');
        return true;
    }

    // Export as CSV
    exportToCSV() {
        const history = this.getHistory();

        if (history.length === 0) {
            alert('No chat history to export. Start a conversation first!');
            return;
        }

        // CSV headers
        let csv = 'Timestamp,User Message,Bot Reply,Issue Category\n';

        // Add data rows
        history.forEach(chat => {
            const timestamp = new Date(chat.timestamp).toLocaleString();
            const userMsg = `"${chat.userMessage.replace(/"/g, '""')}"`;
            const botReply = `"${chat.botReply.replace(/"/g, '""').replace(/\n/g, ' ')}"`;
            const category = chat.issueCategory;

            csv += `${timestamp},${userMsg},${botReply},${category}\n`;
        });

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `chat_history_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        console.log('Chat history exported as CSV successfully');
        return true;
    }

    // Clear all history
    clearHistory() {
        try {
            localStorage.removeItem(this.storageKey);
            console.log('Chat history cleared');
            return true;
        } catch (error) {
            console.error('Error clearing history:', error);
            return false;
        }
    }

    // Get storage statistics
    getStats() {
        const history = this.getHistory();
        return {
            totalChats: history.length,
            firstChat: history.length > 0 ? history[0].timestamp : null,
            lastChat: history.length > 0 ? history[history.length - 1].timestamp : null,
            categories: [...new Set(history.map(chat => chat.issueCategory))]
        };
    }
}

// Export storage instance
const storage = new ChatStorage();
