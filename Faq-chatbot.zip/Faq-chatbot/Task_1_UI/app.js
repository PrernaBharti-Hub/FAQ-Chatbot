// Main application controller
class App {
    constructor() {
        this.currentSection = 'chatbot';
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.displayWelcomeTime();
        this.loadExistingChats();
    }

    // Setup all event listeners
    setupEventListeners() {
        // Navigation buttons
        document.getElementById('chatBtn').addEventListener('click', () => {
            this.switchSection('chatbot');
        });

        document.getElementById('dashboardBtn').addEventListener('click', () => {
            this.switchSection('dashboard');
            dashboard.refresh();
        });

        document.getElementById('exportBtn').addEventListener('click', () => {
            this.showExportOptions();
        });

        // Chat input
        const userInput = document.getElementById('userInput');
        const sendBtn = document.getElementById('sendBtn');

        sendBtn.addEventListener('click', () => {
            this.sendMessage();
        });

        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });

        // Quick action buttons
        document.querySelectorAll('.quick-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const question = e.target.dataset.question;
                this.sendPredefinedMessage(question);
            });
        });

        // Suggestion items
        document.querySelectorAll('.suggestion-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const question = e.currentTarget.dataset.question;
                this.sendPredefinedMessage(question);
            });
        });
    }

    // Switch between sections
    switchSection(section) {
        // Update navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        if (section === 'chatbot') {
            document.getElementById('chatBtn').classList.add('active');
        } else {
            document.getElementById('dashboardBtn').classList.add('active');
        }

        // Update sections
        document.querySelectorAll('.section').forEach(sec => {
            sec.classList.remove('active');
        });

        if (section === 'chatbot') {
            document.getElementById('chatbotSection').classList.add('active');
        } else {
            document.getElementById('dashboardSection').classList.add('active');
        }

        this.currentSection = section;
    }

    // Send message from input
    sendMessage() {
        const userInput = document.getElementById('userInput');
        const message = userInput.value.trim();

        if (!message) return;

        this.processUserMessage(message);
        userInput.value = '';
        userInput.focus();
    }

    // Send predefined message
    sendPredefinedMessage(message) {
        this.processUserMessage(message);
        document.getElementById('userInput').focus();
    }

    // Process user message
    processUserMessage(message) {
        // Display user message
        this.displayMessage(message, 'user');

        // Get bot response
        const chatData = chatbot.processMessage(message);

        // Save to storage
        storage.saveMessage(chatData);

        // Display bot response with slight delay for natural feel
        setTimeout(() => {
            this.displayMessage(chatData.botReply, 'bot');
        }, 500);
    }

    // Display message in chat window
    displayMessage(message, sender) {
        const chatWindow = document.getElementById('chatWindow');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        const avatar = sender === 'bot' ? '🤖' : '👤';
        const bubbleClass = sender === 'bot' ? 'bot-bubble' : 'user-bubble';
        const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        messageDiv.innerHTML = `
            <div class="message-avatar">${avatar}</div>
            <div class="message-content">
                <div class="message-bubble ${bubbleClass}">
                    <p>${this.formatMessage(message)}</p>
                    <div class="message-time">${currentTime}</div>
                </div>
            </div>
        `;

        chatWindow.appendChild(messageDiv);

        // Smooth scroll to bottom
        chatWindow.scrollTo({
            top: chatWindow.scrollHeight,
            behavior: 'smooth'
        });
    }

    // Format message (convert line breaks to <br>)
    formatMessage(message) {
        return message.replace(/\n/g, '<br>');
    }

    // Display welcome message time
    displayWelcomeTime() {
        const welcomeTime = document.querySelector('.bot-message .message-time');
        if (welcomeTime) {
            const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            welcomeTime.textContent = currentTime;
        }
    }

    // Load existing chats from storage
    loadExistingChats() {
        const history = storage.getHistory();

        // Only show recent chats (last 5) on load to avoid clutter
        const recentChats = history.slice(-5);

        if (recentChats.length > 0) {
            // Add a divider
            const chatWindow = document.getElementById('chatWindow');
            const divider = document.createElement('div');
            divider.style.cssText = 'text-align: center; padding: 1rem; color: var(--text-muted); font-size: 0.85rem;';
            divider.innerHTML = '─── Previous Conversations ───';
            chatWindow.appendChild(divider);

            // Display recent chats
            recentChats.forEach(chat => {
                this.displayMessage(chat.userMessage, 'user');
                setTimeout(() => {
                    this.displayMessage(chat.botReply, 'bot');
                }, 100);
            });
        }
    }

    // Show export options
    showExportOptions() {
        const choice = confirm('Export as JSON?\n\nClick OK for JSON\nClick Cancel for CSV');

        if (choice) {
            storage.exportToJSON();
        } else {
            storage.exportToCSV();
        }
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    const app = new App();
    console.log('FAQ Chatbot initialized successfully! 🚀');
});
