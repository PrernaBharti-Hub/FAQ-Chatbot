// FAQ Knowledge Base with 15 predefined responses
const faqDatabase = [
    {
        keywords: ['login', 'log in', 'sign in', 'access', 'enter'],
        response: "To log in to your account:\n1. Go to the login page\n2. Enter your email and password\n3. Click 'Sign In'\n\nIf you're having trouble, try clearing your browser cache or resetting your password.",
        category: 'login'
    },
    {
        keywords: ['password', 'reset password', 'forgot password', 'change password', 'reset'],
        response: "To reset your password:\n1. Click 'Forgot Password' on the login page\n2. Enter your registered email\n3. Check your email for a reset link\n4. Follow the link and create a new password\n\nThe link expires in 24 hours. If you don't receive it, check your spam folder.",
        category: 'password'
    },
    {
        keywords: ['account', 'create account', 'sign up', 'register', 'new account'],
        response: "Creating a new account is easy!\n1. Click 'Sign Up' on the homepage\n2. Fill in your details (name, email, password)\n3. Verify your email address\n4. Complete your profile\n\nYou'll receive a welcome email once registration is complete.",
        category: 'account'
    },
    {
        keywords: ['crash', 'crashing', 'app crash', 'freeze', 'not working', 'broken'],
        response: "I'm sorry the app is crashing. Try these solutions:\n1. Force close and restart the app\n2. Update to the latest version\n3. Clear app cache and data\n4. Reinstall the app if needed\n\nIf the problem persists, please contact support with your device model and OS version.",
        category: 'crash'
    },
    {
        keywords: ['payment', 'pay', 'billing', 'charge', 'credit card', 'transaction'],
        response: "For payment issues:\n1. Verify your payment method is valid and has sufficient funds\n2. Check if your card hasn't expired\n3. Try a different payment method\n4. Contact your bank if the transaction is blocked\n\nAll payments are secure and encrypted. For refunds, contact our billing team.",
        category: 'payment'
    },
    {
        keywords: ['profile', 'update profile', 'edit profile', 'change name', 'personal info'],
        response: "To update your profile:\n1. Go to Settings → Profile\n2. Click 'Edit Profile'\n3. Update your information\n4. Click 'Save Changes'\n\nYou can update your name, photo, bio, and contact information anytime.",
        category: 'profile'
    },
    {
        keywords: ['notification', 'notifications', 'alert', 'not receiving', 'push'],
        response: "To fix notification issues:\n1. Check app notification settings\n2. Verify device notification permissions\n3. Make sure 'Do Not Disturb' is off\n4. Check your notification preferences in Settings\n\nYou can customize which notifications you receive in the app settings.",
        category: 'notification'
    },
    {
        keywords: ['sync', 'synchronize', 'data sync', 'not syncing', 'update'],
        response: "If your data isn't syncing:\n1. Check your internet connection\n2. Log out and log back in\n3. Force sync in Settings → Sync Data\n4. Make sure you're using the latest app version\n\nData syncs automatically when connected to WiFi.",
        category: 'sync'
    },
    {
        keywords: ['feature', 'new feature', 'request', 'suggestion', 'add'],
        response: "We love feature suggestions! 🎉\n1. Go to Settings → Feedback\n2. Describe your feature idea\n3. Submit your request\n\nOur product team reviews all suggestions. Popular requests are prioritized for future updates!",
        category: 'feature'
    },
    {
        keywords: ['support', 'help', 'contact', 'customer service', 'technical support'],
        response: "Need more help? Contact our support team:\n📧 Email: support@example.com\n💬 Live Chat: Available 9 AM - 6 PM\n📱 Phone: 1-800-SUPPORT\n\nAverage response time is under 2 hours during business hours.",
        category: 'support'
    },
    {
        keywords: ['delete', 'delete account', 'remove account', 'close account'],
        response: "To delete your account:\n1. Go to Settings → Account Settings\n2. Scroll to 'Delete Account'\n3. Confirm your decision\n\n⚠️ This action is permanent and cannot be undone. All your data will be deleted within 30 days.",
        category: 'account'
    },
    {
        keywords: ['slow', 'performance', 'lag', 'speed', 'loading'],
        response: "To improve app performance:\n1. Close other apps running in the background\n2. Clear app cache (Settings → Storage)\n3. Ensure you have the latest version\n4. Restart your device\n\nIf you have limited storage, try freeing up space on your device.",
        category: 'crash'
    },
    {
        keywords: ['privacy', 'security', 'data', 'safe', 'secure'],
        response: "Your privacy and security are our top priorities:\n✅ All data is encrypted end-to-end\n✅ We never share your data with third parties\n✅ You can download or delete your data anytime\n✅ Two-factor authentication available\n\nRead our Privacy Policy in Settings → Privacy for more details.",
        category: 'support'
    },
    {
        keywords: ['subscription', 'premium', 'upgrade', 'plan', 'cancel subscription'],
        response: "Managing your subscription:\n• Upgrade: Settings → Subscription → Choose Plan\n• Cancel: Settings → Subscription → Cancel\n• Change Plan: You can upgrade or downgrade anytime\n\nCancellations take effect at the end of the current billing period.",
        category: 'payment'
    },
    {
        keywords: ['referral', 'invite', 'refer friend', 'bonus', 'reward'],
        response: "Earn rewards by referring friends! 🎁\n1. Go to Settings → Refer Friends\n2. Share your unique referral link\n3. Get rewards when friends sign up\n\nBoth you and your friend get benefits when they complete registration!",
        category: 'feature'
    }
];

// Chatbot class
class Chatbot {
    constructor() {
        this.conversationHistory = [];
    }

    // Find best matching FAQ response
    findResponse(userMessage) {
        const messageLower = userMessage.toLowerCase();
        let bestMatch = null;
        let highestScore = 0;

        for (const faq of faqDatabase) {
            let score = 0;
            for (const keyword of faq.keywords) {
                if (messageLower.includes(keyword)) {
                    score += keyword.split(' ').length; // Longer phrases get higher scores
                }
            }

            if (score > highestScore) {
                highestScore = score;
                bestMatch = faq;
            }
        }

        if (bestMatch && highestScore > 0) {
            return {
                response: bestMatch.response,
                category: bestMatch.category
            };
        }

        // Fallback response
        return {
            response: "Sorry, I didn't understand that. 😕\n\nI can help you with:\n• Login & Account issues\n• Password reset\n• Payment problems\n• App crashes\n• Profile updates\n• Notifications\n• And more!\n\nTry asking about one of these topics, or contact our support team for personalized help.",
            category: 'general'
        };
    }

    // Process user message
    processMessage(userMessage) {
        const { response, category } = this.findResponse(userMessage);
        
        const chatData = {
            userMessage: userMessage,
            botReply: response,
            timestamp: new Date().toISOString(),
            issueCategory: category
        };

        this.conversationHistory.push(chatData);
        return chatData;
    }

    // Get conversation history
    getHistory() {
        return this.conversationHistory;
    }

    // Clear history
    clearHistory() {
        this.conversationHistory = [];
    }
}

// Export for use in other modules
const chatbot = new Chatbot();
